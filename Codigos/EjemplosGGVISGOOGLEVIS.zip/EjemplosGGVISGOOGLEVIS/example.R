# # render html a single format
library(rmarkdown)
library(knitr)
render("index.Rmd", "html_document")